package com.example.chalarm

import LoginScreen
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import com.example.chalarm.ui.screens.HomeScreen
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.chalarm.ui.screens.CreateAlarmScreen
import com.example.chalarm.ui.screens.EditAlarmScreen
import com.example.chalarm.viewmodel.AlarmViewModel
import com.example.chalarm.viewmodel.AuthViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            val authViewModel: AuthViewModel = viewModel()
            val alarmViewModel: AlarmViewModel = viewModel()
            val authState by authViewModel.authState.collectAsState()

            LaunchedEffect(Unit) {
                authViewModel.checkUserLoggedIn()
            }
            NavHost(navController = navController, startDestination = "auth_gate") {
                composable("auth_gate") {
                    if (authState == true) {
                        LaunchedEffect(Unit) {
                            alarmViewModel.listenToAlarms()
                            navController.navigate("home") {
                                popUpTo("auth_gate") { inclusive = true }
                            }
                        }
                    } else if (authState == false) {
                        LaunchedEffect(Unit) {
                            navController.navigate("login") {
                                popUpTo("auth_gate") { inclusive = true }
                            }
                        }
                    }
                    // Else (authState == null), do nothing
                }

                composable("login") {
                    LoginScreen(
                        authViewModel = authViewModel,
                        onLoginSuccess = {
                            navController.navigate("home") {
                                popUpTo("login") { inclusive = true }
                            }
                        }
                    )
                }

                composable("home") {
                    HomeScreen(
                        alarmViewModel = alarmViewModel,
                        navController = navController,
                        authViewModel = authViewModel
                    )
                }

                composable("create_alarm") {
                    CreateAlarmScreen(
                        alarmViewModel = alarmViewModel,
                        navController = navController
                    )
                }

                composable("edit_alarm/{alarmId}") { backStackEntry ->
                    val alarmId = backStackEntry.arguments?.getString("alarmId") ?: return@composable
                    EditAlarmScreen(
                        alarmId = alarmId,
                        alarmViewModel = alarmViewModel,
                        navController = navController
                    )
                }
            }
        }
    }
}
