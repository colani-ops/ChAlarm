package com.example.chalarm.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.chalarm.ui.ring.AlarmRingingActivity

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val alarmId = intent.getStringExtra("alarmId") ?: return
            val alarmName = intent.getStringExtra("alarmName") ?: "Alarm"
            val alarmTone = intent.getStringExtra("alarmTone") ?: "alarm1.mp3"
            val alarmVolume = intent.getFloatExtra("alarmVolume", 1.0f)

            val activityIntent = Intent(context, AlarmRingingActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("alarmId", alarmId)
                putExtra("alarmName", alarmName)
                putExtra("alarmTone", alarmTone)
                putExtra("alarmVolume", alarmVolume)
            }

            context.startActivity(activityIntent)

        } catch (e: Exception) {
            Log.e("AlarmReceiver", "Error starting alarm activity", e)
        }
    }

}
