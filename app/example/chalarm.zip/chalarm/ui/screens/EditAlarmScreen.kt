package com.example.chalarm.ui.screens

import androidx.compose.runtime.*
import androidx.navigation.NavController
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.chalarm.viewmodel.AlarmViewModel

@Composable
fun EditAlarmScreen(
    alarmId: String,
    alarmViewModel: AlarmViewModel,
    navController: NavController
) {
    val alarm = alarmViewModel.alarms.collectAsState().value.find { it.id == alarmId }

    if (alarm != null) {
        CreateAlarmScreen(
            existingAlarm = alarm,
            onAlarmSaved = { updatedAlarm ->
                alarmViewModel.updateAlarm(updatedAlarm)
                navController.popBackStack()
            },
            alarmViewModel = alarmViewModel,
            navController = navController
        )
    } else {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    }
}