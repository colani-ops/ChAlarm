package com.example.chalarm.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.chalarm.alarm.AlarmScheduler
import com.example.chalarm.data.Alarm
import com.example.chalarm.viewmodel.AlarmViewModel
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateAlarmScreen(
    existingAlarm: Alarm? = null,
    onAlarmSaved: (Alarm) -> Unit = {},
    alarmViewModel: AlarmViewModel,
    navController: NavController
) {
    val context = LocalContext.current

    var name by remember { mutableStateOf(existingAlarm?.name ?: "") }
    var selectedHour by remember { mutableIntStateOf(7) }
    var selectedMinute by remember { mutableIntStateOf(0) }

    LaunchedEffect(existingAlarm) {
        existingAlarm?.time?.split(":")?.let {
            selectedHour = it.getOrNull(0)?.toIntOrNull() ?: 7
            selectedMinute = it.getOrNull(1)?.toIntOrNull() ?: 0
        }
    }

    var isHourDropdownExpanded by remember { mutableStateOf(false) }
    var isMinuteDropdownExpanded by remember { mutableStateOf(false) }

    val hours = (0..23).toList()
    val minutes = (0..59).toList()

    val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    val selectedDays = remember {
        mutableStateMapOf<String, Boolean>().apply {
            days.forEach { day ->
                this[day] = existingAlarm?.repeatDays?.contains(day) == true
            }
        }
    }

    var tone by remember { mutableStateOf(existingAlarm?.tone ?: "") }
    var selectedToneUri by remember { mutableStateOf<Uri?>(null) }
    val selectedToneName = selectedToneUri?.lastPathSegment ?: "No file selected"

    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedToneUri = uri
        tone = uri?.toString() ?: ""
    }

    var volume by remember { mutableFloatStateOf(existingAlarm?.volume ?: 1.0f) }
    var muteOnStart by remember { mutableStateOf(existingAlarm?.muteOnStart ?: false) }
    var snoozeEnabled by remember { mutableStateOf(existingAlarm?.snoozeEnabled ?: true) }
    var snoozeTimeMinutes by remember { mutableStateOf(existingAlarm?.snoozeTimeMinutes?.toString() ?: "5") }
    var numChallenges by remember { mutableStateOf(existingAlarm?.numChallenges?.toString() ?: "1") }

    val challengeOptions = listOf("Memory", "Math", "Retype", "Face", "Steps")
    val selectedChallenges = remember {
        mutableStateMapOf<String, Boolean>().apply {
            challengeOptions.forEach { challenge ->
                this[challenge] = existingAlarm?.challengeTypes?.contains(challenge) == true
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Create Alarm", style = MaterialTheme.typography.headlineMedium)

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Alarm Name") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            // Hour Picker
            Column {
                Text("Hour")
                ExposedDropdownMenuBox(
                    expanded = isHourDropdownExpanded,
                    onExpandedChange = { isHourDropdownExpanded = !isHourDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedHour.toString().padStart(2, '0'),
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .menuAnchor()
                            .width(100.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = isHourDropdownExpanded,
                        onDismissRequest = { isHourDropdownExpanded = false },
                        modifier = Modifier.heightIn(max = 150.dp) // ⬅ Limits height
                    ) {
                        hours.forEach {
                            DropdownMenuItem(
                                text = { Text(it.toString().padStart(2, '0')) },
                                onClick = {
                                    selectedHour = it
                                    isHourDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // Minute Picker
            Column {
                Text("Minute")
                ExposedDropdownMenuBox(
                    expanded = isMinuteDropdownExpanded,
                    onExpandedChange = { isMinuteDropdownExpanded = !isMinuteDropdownExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedMinute.toString().padStart(2, '0'),
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .menuAnchor()
                            .width(100.dp)
                    )
                    ExposedDropdownMenu(
                        expanded = isMinuteDropdownExpanded,
                        onDismissRequest = { isMinuteDropdownExpanded = false },
                        modifier = Modifier.heightIn(max = 150.dp) // ⬅ Limits height
                    ) {
                        minutes.forEach {
                            DropdownMenuItem(
                                text = { Text(it.toString().padStart(2, '0')) },
                                onClick = {
                                    selectedMinute = it
                                    isMinuteDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }





            Spacer(modifier = Modifier.height(12.dp))

        Text("Repeat Days", style = MaterialTheme.typography.titleMedium)

        Column {
            days.chunked(4).forEach { rowItems ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { day ->
                        FilterChip(
                            selected = selectedDays[day] == true,
                            onClick = { selectedDays[day] = !(selectedDays[day] ?: false) },
                            label = { Text(day) }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text("Selected Tone Path: $selectedToneName")
        Button(onClick = { audioPickerLauncher.launch("audio/*") }) {
            Text("Choose Custom Alarm Tone")
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text("Volume: ${(volume * 100).toInt()}%")
        Slider(value = volume, onValueChange = { volume = it })

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = muteOnStart, onCheckedChange = { muteOnStart = it })
            Text("Mute on Start")
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = snoozeEnabled, onCheckedChange = { snoozeEnabled = it })
            Text("Enable Snooze")
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text("Snooze Duration: $snoozeTimeMinutes min")
        Slider(
            value = snoozeTimeMinutes.toFloatOrNull() ?: 5f,
            onValueChange = { snoozeTimeMinutes = it.toInt().coerceIn(1, 5).toString() },
            valueRange = 1f..5f,
            steps = 3
        )

        OutlinedTextField(
            value = numChallenges,
            onValueChange = { numChallenges = it },
            label = { Text("Number of Challenges") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))
        Text("Challenge Types", style = MaterialTheme.typography.titleMedium)

        Column {
            challengeOptions.chunked(3).forEach { rowItems ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { challenge ->
                        FilterChip(
                            selected = selectedChallenges[challenge] == true,
                            onClick = { selectedChallenges[challenge] = !(selectedChallenges[challenge] ?: false) },
                            label = { Text(challenge) }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Button(
                onClick = {
                    val newAlarm = Alarm(
                        id = existingAlarm?.id ?: UUID.randomUUID().toString(),
                        name = name,
                        time = "%02d:%02d".format(selectedHour, selectedMinute),
                        repeatDays = selectedDays.filterValues { it }.keys.toList(),
                        tone = tone,
                        volume = volume,
                        muteOnStart = muteOnStart,
                        snoozeEnabled = snoozeEnabled,
                        snoozeTimeMinutes = snoozeTimeMinutes.toIntOrNull() ?: 5,
                        numChallenges = numChallenges.toIntOrNull() ?: 1,
                        challengeTypes = selectedChallenges.filterValues { it }.keys.toList(),
                        isEnabled = true
                    )

                    if (existingAlarm == null) alarmViewModel.addAlarm(newAlarm)
                    else alarmViewModel.updateAlarm(newAlarm)

                    AlarmScheduler(context).scheduleAlarm(newAlarm)
                    onAlarmSaved(newAlarm)
                    navController.navigate("home") {
                        popUpTo("home") { inclusive = true }
                    }

                }
            ) {
                Text("Save Alarm")
            }
        }
    }
}
