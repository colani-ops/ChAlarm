package com.example.chalarm.ui.ring

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.example.chalarm.R

class AlarmRingingActivity : Activity() {

    private var mediaPlayer: MediaPlayer? = null
    private var snoozeEnabled: Boolean = true
    private var snoozeTimeMinutes: Int = 5

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm_ringing)

        val alarmName = intent.getStringExtra("name") ?: "Alarm"
        val volume = intent.getFloatExtra("volume", 1.0f)
        val tone = intent.getStringExtra("tone") ?: ""
        snoozeEnabled = intent.getBooleanExtra("snoozeEnabled", true)
        snoozeTimeMinutes = intent.getIntExtra("snoozeTimeMinutes", 5)

        findViewById<TextView>(R.id.alarmTitle).text = alarmName

        try {
            val uri = if (tone.startsWith("content://")) {
                Uri.parse(tone)
            } else {
                val resId = resources.getIdentifier(tone.removeSuffix(".mp3"), "raw", packageName)
                Uri.parse("android.resource://$packageName/$resId")
            }

            mediaPlayer = MediaPlayer.create(this, uri)
            mediaPlayer?.setVolume(volume, volume)
            mediaPlayer?.isLooping = true
            mediaPlayer?.start()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        findViewById<Button>(R.id.dismissButton).setOnClickListener {
            stopAlarm()
        }

        val snoozeButton = findViewById<Button>(R.id.snoozeButton)
        if (snoozeEnabled) {
            snoozeButton.setOnClickListener {
                snoozeAlarm()
                stopAlarm()
            }
        } else {
            snoozeButton.isEnabled = false
            snoozeButton.alpha = 0.5f
        }
    }

    private fun stopAlarm() {
        mediaPlayer?.stop()
        mediaPlayer?.release()
        mediaPlayer = null
        finish()
    }

    private fun snoozeAlarm() {
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        val snoozeTime = System.currentTimeMillis() + (snoozeTimeMinutes * 60 * 1000)

        val intent = intent

        val pendingIntent = PendingIntent.getBroadcast(
            this,
            intent.getStringExtra("alarmId")?.hashCode() ?: 0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                snoozeTime,
                pendingIntent
            )
        } catch (e: SecurityException) {
            e.printStackTrace()
            // Optionally: show a toast or log for debugging
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
    }
}
