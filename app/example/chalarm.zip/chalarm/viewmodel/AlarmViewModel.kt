package com.example.chalarm.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import com.example.chalarm.data.Alarm
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.firestore
import java.util.*

class AlarmViewModel : ViewModel() {

    private val _alarms = MutableStateFlow<List<Alarm>>(emptyList())
    val alarms: StateFlow<List<Alarm>> get() = _alarms

    private val db = Firebase.firestore
    private val userId = FirebaseAuth.getInstance().currentUser?.uid



    fun listenToAlarms() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

        Firebase.firestore
            .collection("users").document(userId)
            .collection("alarms")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("AlarmViewModel", "Listen failed", error)
                    return@addSnapshotListener
                }

                if (snapshot != null && !snapshot.isEmpty) {
                    val alarmList = snapshot.documents.mapNotNull { it.toObject(Alarm::class.java) }
                    _alarms.value = alarmList
                    Log.d("AlarmViewModel", "Alarms updated: ${alarmList.size}")
                } else {
                    _alarms.value = emptyList()
                }
            }
    }


    fun addAlarm(alarm: Alarm) {
        val id = UUID.randomUUID().toString()
        val newAlarm = alarm.copy(id = id)

        userId?.let { uid ->
            db.collection("users").document(uid)
                .collection("alarms").document(id)
                .set(newAlarm)
                .addOnSuccessListener {
                    Log.d("AlarmViewModel", "Alarm saved to Firestore: $newAlarm")
                    _alarms.value = _alarms.value + newAlarm
                }
                .addOnFailureListener {
                    Log.e("AlarmViewModel", "Failed to save alarm: $it")
                }
        }
    }

    fun deleteAlarm(alarmId: String) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return

        Firebase.firestore
            .collection("users")
            .document(userId)
            .collection("alarms")
            .document(alarmId)
            .delete()
            .addOnSuccessListener {
                _alarms.value = _alarms.value.filterNot { it.id == alarmId }
                Log.d("AlarmViewModel", "Deleted alarm: $alarmId")
            }
            .addOnFailureListener { e ->
                Log.e("AlarmViewModel", "Failed to delete alarm: $e")
            }
    }


    fun updateAlarm(updatedAlarm: Alarm) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val alarmRef = db.collection("users").document(userId)
            .collection("alarms").document(updatedAlarm.id)

        alarmRef.set(updatedAlarm)
            .addOnSuccessListener {
                Log.d("AlarmViewModel", "Alarm updated: ${updatedAlarm.id}")

                // Update local state
                val currentAlarms = _alarms.value.toMutableList()
                val index = currentAlarms.indexOfFirst { it.id == updatedAlarm.id }

                if (index != -1) {
                    currentAlarms[index] = updatedAlarm
                    _alarms.value = currentAlarms
                }
            }
            .addOnFailureListener { e ->
                Log.e("AlarmViewModel", "Failed to update alarm: ${updatedAlarm.id}", e)
            }
    }




    fun getAlarmById(id: String): Alarm? {
        return _alarms.value.find { it.id == id }
    }
}
