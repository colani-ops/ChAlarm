package com.example.chalarm.data

import androidx.annotation.Keep

@Keep
data class Alarm(
    val id: String = "",
    val name: String = "",
    val time: String = "",
    val repeatDays: List<String> = emptyList(),
    val tone: String = "",
    val volume: Float = 1f,
    val muteOnStart: Boolean = false,
    val snoozeEnabled: Boolean = false,
    val snoozeTimeMinutes: Int = 5,
    val numChallenges: Int = 1,
    val challengeTypes: List<String> = emptyList(),
    val toneUri: String? = null, // Uri of custom selected sound
    val isEnabled: Boolean = true
)


data class ChallengeConfig(
    val memoryPairs: Int = 2,
    val retypeLength: Int = 4,
    val mathTypes: List<String> = listOf("Add", "Subtract")
)
